URL_SERVICE = # Inserta tu dirección de URL sin la barra diagonal al final
CREATE_USER_PATH = # Almacena la ruta para crear un usuario o usuaria en esta variable
KITS_PATH = # Almacena la ruta para crear un kit en esta variable
